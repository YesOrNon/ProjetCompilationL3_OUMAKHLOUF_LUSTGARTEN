Analyseur syntaxique de OUMAKHLOUF Selym et LUSTGARTEN Léo
Projet L3 Informatique 
2023-2024

Ce projet effectue la lecture d'un fichier de langage tpc et produit un arbre abstrait

Compilation :
  make
  ./bin/tpcas < [FICHIER]

Option : -t ou --tree pour afficher l'arbre
         -h ou --help pour l'aide

Pour lancer le script test.sh :
      Pour obtenir les droits d'éexecution : chmod +x test.sh
      pour lancer le script : ./test.sh (produit un rapport.txt dans le dossier rep)
        