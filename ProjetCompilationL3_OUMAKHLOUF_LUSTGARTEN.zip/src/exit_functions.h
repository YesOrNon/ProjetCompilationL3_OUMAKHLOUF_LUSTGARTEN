#ifndef __CLOSE__
#define __CLOSE__


void closeFile(int status, void *file);

void closeProgTable(int status, void *table);

#endif
